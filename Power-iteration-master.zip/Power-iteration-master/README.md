# Power-iteration
C++ code applying power iteration with deflation in order to find eigenvalues and eigenvectors of any vectors with non-complex eigenvalues. The code uses Matrix class.
You can use the code in Matrix.cpp and Matrix.h in your projects asking you to do Matrix operations. The use of classes will make the operations much easier.
